import InneKlasy.Sklep;
import InneKlasy.Kwiaciarnia;
import InneKlasy.DataUtils;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args)throws Exception {
        System.out.println("\n Zadanie 1 \n");
        Sklep sklep = new Sklep("ul. Przykładowa 1", 100, true, 2000);
        System.out.println(sklep); // wypisze: Adres sklepu: ul. Przykładowa 1, powierzchnia lokalu: 100.0 m^2, WC: tak, czynsz najmu: 2000.0 zł/mies.
        System.out.println("Liczba możliwych półek: " + sklep.liczIloscPolek()); // wypisze: Liczba możliwych półek: 50
        System.out.println("Czynsz za 6 miesięcy: " + sklep.obliczCzynsz(6) + " zł"); // wypisze: Czynsz za 6 miesięcy: 12000.0 zł

        System.out.println("\n Zadanie 2 \n");

        Kwiaciarnia kwiaciarnia = new Kwiaciarnia("ul. Kwiatowa 2", 50, true, 1500, 20);
        System.out.println(kwiaciarnia); // wypisze: Adres kwiaciarni: ul. Kwiatowa 2, powierzchnia lokalu

        System.out.println("\n Zadanie 3 \n");

        LocalDate data1 = LocalDate.of(2005, 10, 17);
        LocalDate data2 = LocalDate.of(2023, 3, 07);
        int roznicaMiesiace = DataUtils.roznicaDatMiesiace(data1, data2);
        int roznicaDni = DataUtils.roznicaDatDni(data1, data2);
        LocalDate dataPoInterwale = DataUtils.dataPoInterwaleDni(data1, 10);

        System.out.println("Różnica między datami w miesiącach: " + roznicaMiesiace); // wynik: 1
        System.out.println("Różnica między datami w dniach: " + roznicaDni); // wynik: 41
        System.out.println("Data po interwale 10 dni od " + data1 + ": " + dataPoInterwale); // wynik: 2019-05-22


    }
}