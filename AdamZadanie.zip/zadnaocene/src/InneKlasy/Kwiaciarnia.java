package InneKlasy;

public class Kwiaciarnia extends Sklep {
    private double powierzchniaZaplecza;

    // konstruktor
    public Kwiaciarnia(String adres, double powierzchnia, boolean czyJestWc, double czynszNajmu, double powierzchniaZaplecza) {
        super(adres, powierzchnia, czyJestWc, czynszNajmu);
        this.powierzchniaZaplecza = powierzchniaZaplecza;
    }

    // przesłonięta metoda toString()
    @Override
    public String toString() {
        String wc = czyJestWc ? "tak" : "nie";
        return "Adres kwiaciarni: " + adres + ", powierzchnia lokalu: " + powierzchnia + " m^2, WC: " + wc +
                ", czynsz najmu: " + czynszNajmu + " zł/mies., powierzchnia zaplecza: " + powierzchniaZaplecza + " m^2";
    }

    // przesłonięta metoda liczaca ilosc mozliwych do rozstawienia polek
    @Override
    public int liczIloscPolek() {
        double calkowitaPowierzchnia = powierzchnia + powierzchniaZaplecza;
        return (int) (calkowitaPowierzchnia / 4);
    }
}
